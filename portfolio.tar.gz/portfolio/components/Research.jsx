'use client';

import { motion } from 'framer-motion';
import SectionTitle from './SectionTitle';
import { certificates, researchPapers } from '@/lib/data';
import { Award, Eye, Cpu, Cloud, FileText, ExternalLink } from 'lucide-react';

const iconMap = {
  Award,
  Eye,
  Cpu,
  Cloud,
};

export default function Research() {
  return (
    <section id="research" className="section-padding bg-gradient-to-b from-transparent to-black/20">
      <div className="max-w-7xl mx-auto">
        <SectionTitle 
          title="Research & Achievements" 
          subtitle="Academic contributions and professional certifications"
        />

        {/* Research Papers */}
        <div className="mb-16">
          <h3 className="text-2xl font-orbitron font-bold mb-8 text-cyan-400">
            Research Publications
          </h3>
          <div className="space-y-6">
            {researchPapers.map((paper, index) => (
              <motion.div
                key={paper.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02 }}
                className="glass-card p-6 rounded-xl hover:glow-effect transition-all duration-300"
              >
                <div className="flex items-start gap-4">
                  <FileText className="text-cyan-400 mt-1 flex-shrink-0" size={24} />
                  <div className="flex-1">
                    <h4 className="text-xl font-bold mb-2">{paper.title}</h4>
                    <p className="text-cyan-400 text-sm mb-2">
                      {paper.venue} • {paper.year}
                    </p>
                    <p className="text-slate-400">
                      {paper.description}
                    </p>
                  </div>
                  <ExternalLink className="text-slate-400 hover:text-cyan-400 cursor-pointer flex-shrink-0" size={20} />
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Certificates */}
        <div>
          <h3 className="text-2xl font-orbitron font-bold mb-8 text-cyan-400">
            Certifications
          </h3>
          <div className="grid md:grid-cols-2 gap-6">
            {certificates.map((cert, index) => {
              const Icon = iconMap[cert.icon];
              return (
                <motion.div
                  key={cert.id}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.05, y: -5 }}
                  className="glass-card p-6 rounded-xl hover:glow-effect transition-all duration-300 group"
                >
                  <div className="flex items-start gap-4">
                    <div className="p-3 rounded-lg bg-cyan-500/20 group-hover:bg-cyan-500/30 transition-colors">
                      <Icon className="text-cyan-400" size={28} />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-lg font-bold mb-1">{cert.title}</h4>
                      <p className="text-cyan-400 text-sm mb-2">
                        {cert.issuer} • {cert.date}
                      </p>
                      <p className="text-slate-400 text-sm">
                        {cert.description}
                      </p>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
